To use, run HeapMain, HashMain, or Hash2Main.

HeapMain Instructions:
	Type filename, use entire path
    File formatting should be: <output style> <size> <operations>
    Use X.in to insert and del to delete
    Examples: post 3.in del 6.in

HashMain Instructions:
	Type filename, use entire path
    File formatting should be: <size> <operations>
    Use X.in to insert and X.del to delete
    Examples: 3.in 3.del 5.in 5.sch

Hash2Main Instructions:
	Type filename, use entire path
    File formatting should be: <size> <operations>
    Use X.in to insert and X.del to delete
    Examples: 3.in 3.del 5.in 5.del
