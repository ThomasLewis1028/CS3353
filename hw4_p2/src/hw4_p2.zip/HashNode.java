public class HashNode {
    HashNode next;
    int data;

    /* Constructor */
    public HashNode(int x) {
        data = x;
        next = null;
    }
}
